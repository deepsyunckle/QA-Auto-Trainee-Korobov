import java.io.IOException;


public class Algorithm3 {
    public static void main(String[] args) throws IOException {
        calculatingTheArray newArray = new calculatingTheArray();
        newArray.arrayLine("put your array here");
    }
}

