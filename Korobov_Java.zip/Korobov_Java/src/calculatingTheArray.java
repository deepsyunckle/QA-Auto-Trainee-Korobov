public class calculatingTheArray {
    public void arrayLine(int[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] % 3 == 0) {
                System.out.println("Array elements what can be divided by 3: " + array[i]);
            }
        }
    }
}
