import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Algorithm1 {
    public static void main(String[] args) throws IOException {
        System.out.println("Please, input the number: ");
        BufferedReader readTheNumber = new BufferedReader(new InputStreamReader(System.in));
        int number = Integer.parseInt(readTheNumber.readLine());
        if (number > 7) {
            System.out.println("Привет!");
        }
    }
}
